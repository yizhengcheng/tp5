<?php
namespace app\index\Controller;
use think\Controller;
use Util\data\Sysdb;

/*

前台首页

 */


class Index extends Controller
{

    public function __construct(){
        parent::__construct();
        $this->db=new Sysdb;
    }

    //首页
    public function index()
    {
        //首页幻灯片
        $data=$this->db->table('slide')->where(array('type'=>0))->lists();
        $this->assign('data',$data);
        //导航标签
        $channel_list=$this->db->table('video_label')->where(array('flag'=>'channel'))->order('ord asc')->pages(8);
        //dump($channel_list);
        $this->assign('channel_list', $channel_list['lists']);

        //今日焦点
        $today_hot_list=$this->db->table('video')->where(array('channel_id'=>1,'status'=>1))->pages(2);
        $this->assign('today_hot_list', $today_hot_list['lists']);
         // dump($today_hot_list);
        //显示模板
        return $this->fetch();
    }

    //影片类型
    public function cate(){

        $data=$this->db->table('slide')->where(array('type'=>0))->lists();
        $this->assign('data',$data);
        //导航标签
        $channel_list=$this->db->table('video_label')->where(array('flag'=>'channel'))->order('ord asc')->pages(8);
        //dump($channel_list);
        $this->assign('channel_list', $channel_list['lists']);

        //今日焦点
        $today_hot_list=$this->db->table('video')->where(array('channel_id'=>1,'status'=>1))->pages(2);
        $this->assign('today_hot_list', $today_hot_list['lists']);
        // echo 111;
        return $this->fetch();
    }

}
