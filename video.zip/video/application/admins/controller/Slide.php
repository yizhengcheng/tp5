<?php
/*
幻灯片管理
 */
namespace app\admins\controller;
use app\admins\controller\BaseAdmin;

class Slide extends BaseAdmin{

//幻灯片列表
public function index(){

$data['data']=$this->db->table('slide')->where(array('type'=>0))->lists();
$this->assign('data',$data);
    return $this->fetch();
}

//添加
public function add(){
   $id=(int)input('get.id');
    $data['item']=$this->db->table('slide')->where(array('id'=>$id))->item();
    //var_dump($data['item']);
    $this->assign('data',$data);
    return $this->fetch();
}



//保存
public function save(){
    $id=(int)input('post.id');

    $data['title']=trim(input('post.title'));
    $data['url']=trim(input('post.url'));
    $data['img']=trim(input('post.img'));
    $data['ord']=trim(input('post.ord'));
    if($data['title']==''){
        exit(json_encode(array('code'=>1,'msg'=>'影片名不能为空!')));
    }
    if($data['url']==''){
        exit(json_encode(array('code'=>1,'msg'=>'请输入影片url')));
    }


if($id>0){
        $this->db->table('slide')->where(array('id'=>$id))->update($data);
        exit(json_encode(array('code'=>0,'msg'=>'保存成功')));
}else
{
    $this->db->table('slide')->insert($data);
    exit(json_encode(array('code'=>0,'msg'=>'保存成功')));
}


}



//删除
public function delete(){

 $id=(int)trim(input('post.id'));
 $this->db->table('slide')->where(array('id'=>$id))->delete();
 exit(json_encode(array('code'=>0,'msg'=>'删除成功')));

}




}
