<?php
namespace app\admins\Controller;
use think\Controller;
use Util\data\Sysdb;
/**
管理员管理
 */
class Admin extends BaseAdmin{

  //管理员列表
  public function index(){
     $data['lists']=$this->db->table('admin')->lists();
     //加载角色
    $data['groups']=$this->db->table('admin_groups')->cates('gid');
     $this->assign('data',$data);
     return $this->fetch();
  }

//添加角色
  public function add(){
    //接受id
    $id=(int)input('get.id');
    //加载管理员
    $data['item']=$this->db->table('admin')->where(array('id'=>$id))->item();
    //加载角色
    $data['lists']=$this->db->table('admin_groups')->cates('gid');

    $this->assign('data',$data);
    return $this->fetch();
  }

  //保存角色
  public function save(){

    $id=(int)input('post.id');
    $data['gid']=(int)input('post.gid');
    $data['status']=trim(input("post.status"));
    $data['username']=trim(input("post.username"));
    $password=trim(input("post.password"));
    $data['truename']=trim(input("post.truename"));

    // dump($data);
    if(!$data['username']){
      exit(json_encode(array('code'=>1,'msg'=>'用户名不能为空')));
    }
    if(!$data['gid']){
      exit(json_encode(array('code'=>1,'msg'=>'角色不能为空')));
    }
    if($id==0 && !$password){
      exit(json_encode(array('code'=>1,'msg'=>'密码不能为空')));
    }
    if(!$data['truename']){
      exit(json_encode(array('code'=>1,'msg'=>'姓名不能为空')));
    }
    $data['password']=md5($data['username'].$password);

    $res=true;

    if($id==0){
      //检查用户名是否存在
    $item=$this->db->table('admin')->where(array('username'=>$data['username']))->item();
    if($item){
      exit(json_encode(array('code'=>1,'msg'=>'用户名已存在')));
    }
    $data['addtime']=time();
     //保存用户
     $res=$this->db->table('admin')->insert($data);
    }else{
      //修改
      $res=$this->db->table('admin')->where(array('id'=>$id))->update($data);
    }


    if(!$res){
      exit(json_encode(array('code'=>1,'msg'=>'保存失败')));
    }
    exit(json_encode(array('code'=>0,'msg'=>'保存成功')));


  }

//删除
public function delete(){
      $id=(int)input('post.id');
      $res=$this->db->table('admin')->where(array('id'=>$id))->delete();
      if(!$res){
        exit(json_encode(array('code'=>1,'msg'=>'删除失败')));
      }
      exit(json_encode(array('code'=>0,'msg'=>'删除成功')));
}



}