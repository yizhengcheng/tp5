<?php
namespace app\admins\Controller;
use think\Controller;
use Util\data\Sysdb;
/**
 * @Author: anchen
 * @Date:   2019-02-27 10:29:39
 * @Last Modified by:   anchen
 * @Last Modified time: 2019-02-28 16:47:11
 */
/**
 *
 */
class Test extends Controller
{
    public function index()
    {
        $this->db=new Sysdb;
        $res=$this->db->table('admin')->field("id,username")->where(array('id'=>2))->lists();
        // $res2=$this->db->table('admin')->item();
        dump($res);
        echo "<hr>";
        $res2=$this->db->table('admin')->field('id,username')->cates('id');
        dump($res2);
    }

}
