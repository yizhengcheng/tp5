<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"D:\web\www\video\public/../application/admins\view\slide\add.html";i:1551515692;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <link rel="stylesheet" type="text/css" href="/static/plusins/layui/css/layui.css">
   <script type="text/javascript" src="/static/plusins/layui/layui.js"></script>
</head>
<body style="padding: 10px;">
<form class="layui-form">
  <input type="hidden" name="id" value="<?php echo $data['item']['id']; ?>">
    <div class="layui-form-item">
        <label class="layui-form-label">标题</label>
        <div class="layui-input-block">
            <input type="text" class="layui-input" name="title"  value="<?php echo $data['item']['title']; ?>" />
        </div>
    </div>

  <div class="layui-form-item">
        <label class="layui-form-label">排序</label>
        <div class="layui-input-block">
            <input type="text" class="layui-input" name="ord"  value="<?php echo $data['item']['ord']; ?>" />
        </div>
    </div>
    <div class="layui-form-item">
        <label class="layui-form-label">URL</label>
        <div class="layui-input-block">
            <input type="text" class="layui-input" name="url"  value="<?php echo $data['item']['url']; ?>" />
        </div>
    </div>




    <div class="layui-form-item">
        <label class="layui-form-label">图片上传</label>
        <div class="layui-input-block">
           <button class="layui-btn layui-btn-sm"  id="upload_img" onclick="return false;">上传</button>
           <img <?php if($data['item']['img']){echo 'src="'.$data['item']['img'].'"';}?> style="height: 30px;" id="pre_img">
           <input type="hidden" name="img" value="<?php echo $data['item']['img']; ?>">
        </div>
    </div>



</form>

<hr>

    <div class="layui-form-item">
        <label class="layui-form-label"></label>
        <div class="layui-input-block">
            <button class="layui-btn" onclick="save()">保存</button>
        </div>
    </div>
</body>
</html>

<script type="text/javascript">
 layui.use(['layer','form','upload'],function(){
            form=layui.form;
            layer=layui.layer;
            $=layui.jquery;
           var upload = layui.upload;



          //执行实例 图片上传
          var uploadInst = upload.render({
            elem: '#upload_img' //绑定元素
            ,url: '/admins.php/admins/video/upload_img' //上传接口
            ,accept:'images'
            ,done: function(res){
              //上传完毕回调
              console.log(res);
              $("#pre_img").attr('src',res.msg);
              $('input[name="img"]').val(res.msg);
              // if(res.code>0){
              //   layer.alert(res.msg,{icon:2});
              // }else{
              //   layer.msg(res.msg);
              // }
            }
            ,error: function(){
              //请求异常回调
            }
          });






     });
//保存
    function save(){
        var title = $.trim($('input[name="title"]').val());
        var url = $.trim($('input[name="url"]').val());


        if(title==''){
            layer.msg('请输入标题',{'icon':2,'anim':6});

        }
        if(url== ''){
            layer.msg('请输入URL',{'icon':2,'anim':6});

        }



          $.post('/admins.php/admins/slide/save',$('form').serialize(),function(res){
                    if(res.code>0){
                       layer.msg(res.msg,{icon:2,'anim':6});
                    }
                    else{
                      layer.msg(res.msg,{'icon':1});
                      setTimeout(function(){parent.window.location.reload()},1000);
                    }
          },'json');
    }

</script>