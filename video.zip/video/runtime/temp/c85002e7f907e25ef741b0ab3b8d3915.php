<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"D:\web\www\video\public/../application/admins\view\account\login.html";i:1551266305;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>登录</title>

    <link rel="stylesheet" href="/static/plusins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plusins/layui/layui.js"></script>

</head>
<body style="background:#1E9FFF">

<div style="position: absolute;left: 50%;top: 50%;width: 500px;margin-left:-250px;margin-top:-200px;">
    <div style="background:#ffffff;padding: 20px;border-radius:4px;box-shadow: 5px 5px 20px #444444;">
        <div class="layui-form">

            <div class="layui-form-item" style="color:gray">
                <h2>后台管理系统</h2>
            </div>
            <hr>

    <div class="layui-form-item">
    <label class="layui-form-label">用户名</label>
    <div class="layui-input-block">
      <input type="text" name="user" id="username" class="layui-input">
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label">密&nbsp;&nbsp;&nbsp;码</label>
    <div class="layui-input-block">
      <input type="password" name="password" id="password"  class="layui-input">
    </div>
 </div>


  <div class="layui-form-item">
    <label class="layui-form-label">验证码</label>
    <div class="layui-input-inline">
      <input type="text" name="verifycode" id="verifycode" class="layui-input">
    </div>
    <img src="<?php echo captcha_src(); ?>" id="img" onclick="reloadImg()" />
 </div>

 <div class="layui-form-item">
    <div class="layui-input-block">
      <button class="layui-btn" onclick="dologin()">立即提交</button>
      <button type="reset" class="layui-btn" >重置</button>
    </div>
  </div>





        </div>
    </div>
</div>

 <script  type="text/javascript">
layui.use('layer', function(){
    $ = layui.$ //由于layer弹层依赖jQuery，所以可以直接得到
    layer = layui.layer;

    //用户名获取焦点
    $("#username").focus();
    //回车登录
    $('input').keydown(function(e) {
          if(e.keyCode==13){
            dologin();
          }
    });
});

//重新生成验证码
function reloadImg(){
      $("#img").attr('src','<?php echo captcha_src(); ?>?rand='+Math.random())
}



function dologin()
{
  var username = $.trim($("#username").val());
  var password = $.trim($("#password").val());
  var verifycode = $.trim($("#verifycode").val());
  if(username==''){
    layer.alert('请输入用户名',{icon:2});
    return;
  }
  if(password==''){
    layer.alert('请输入密码',{icon:2});
    return;
  }
  if(verifycode==''){
    layer.alert('请输入验证码',{icon:2});
    return;
  }

  $.post('/admins.php/admins/Account/dologin', {'username':username,'password':password,'verifycode':verifycode}, function(res){
              if(res.code>0){
                reloadImg();
                layer.alert(res.msg,{icon:2});
              }else{
                layer.msg(res.msg);
                setTimeout(function(){window.location.href="/admins.php/admins/Home/index"},1000);
              }
      },'json');

}


</script>


</body>

</html>