<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"D:\web\www\video\public/../application/admins\view\roles\index.html";i:1551423380;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
     <link rel="stylesheet" href="/static/plusins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plusins/layui/layui.js"></script>

     <style type="text/css">
        .header span{background:#009688;margin-left: 30px;padding: 10px;color:#ffffff}
        .header div{border-bottom: solid 2px #009688;margin-top: 8px;}
        .header button{float:right;margin-top:-5px;}
    </style>
</head>
<body style="padding: 10px;">
<div class="header">
        <span>角色列表</span>
        <button class="layui-btn layui-btn-sm" onclick="add()">添加</button>
        <div></div>
    </div>

    <table class="layui-table">
        <thead>
            <tr>
                <th>gid</th>
                <th>角色名称</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
            <?php if(is_array($data['roles']) || $data['roles'] instanceof \think\Collection || $data['roles'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['roles'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <tr>
                <td><?php echo $vo['gid']; ?></td>
                <td><?php echo $vo['title']; ?></td>
                <td>
                    <button class="layui-btn layui-btn-warm layui-btn-xs" onclick="add(<?php echo $vo['gid']; ?>)">编辑</button>
                    <button class="layui-btn layui-btn-danger layui-btn-xs" onclick="dele(<?php echo $vo['gid']; ?>)">删除</button>
                </td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </tbody>
    </table>
</body>
<script type="text/javascript">
    layui.use(['layer'],function(){
        $ = layui.jquery;
        layer = layui.layer;
    });

    // 添加
    function add(gid){
        layer.open({
          type: 2,
          title: gid>0?'编辑角色':'添加角色',
          shade: 0.3,
          area: ['600px', '620px'],
          content: '/admins.php/admins/Roles/add?gid='+gid
        });
    }

    function dele(gid){
         layer.confirm('确认要删除？', {
            icon:3,
          btn: ['确认','取消'] //按钮
        }, function(){
          $.post('/admins.php/admins/Roles/deletes', {'gid':gid}, function(res) {
              if(res.code>0){
                layer.alert(res.msg,{icno:2});
              }
              else{
                layer.msg(res.msg);
                setTimeout(function(){window.location.reload()},1000);
              }

          },'json');
        });
    }
</script>
</html>