<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:65:"D:\web\www\video\public/../application/admins\view\video\add.html";i:1551508511;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
   <link rel="stylesheet" type="text/css" href="/static/plusins/layui/css/layui.css">
   <script type="text/javascript" src="/static/plusins/layui/layui.js"></script>
</head>

<body style="padding:10px;">
  <form class="layui-form">
<input type="hidden" value="<?php echo $data['item']['id']; ?>" name="id">
  <div class="layui-form-item">
    <label class="layui-form-label">影片名称:</label>
    <div class="layui-input-block">
    <input type="text"  class="layui-input" name="title" value="<?php echo $data['item']['title']; ?>"  >
    </div>
  </div>

  <div class="layui-form-item">
    <label class="layui-form-label">频道</label>
    <div class="layui-input-inline">
      <select name="channel_id">
        <option value="0">请选择频道</option>
        <?php if(is_array($data['channel']) || $data['channel'] instanceof \think\Collection || $data['channel'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['channel'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['id']; ?>" <?php if($data['item']['channel_id']==$vo['id']){echo 'selected';}?>><?php echo $vo['title']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
    </div>
    <label class="layui-form-label">资费</label>
    <div class="layui-input-inline">
      <select name="charge_id">
        <option value="0">请选择资费</option>
        <?php if(is_array($data['charge']) || $data['charge'] instanceof \think\Collection || $data['charge'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['charge'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['id']; ?>" <?php if($data['item']['charge_id']==$vo['id']){echo 'selected';}?>><?php echo $vo['title']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
    </div>
  </div>



<div class="layui-form-item">
    <label class="layui-form-label">地区</label>
    <div class="layui-input-inline">
      <select name="area_id">
        <option value="0">请选择地区</option>
        <?php if(is_array($data['area']) || $data['area'] instanceof \think\Collection || $data['area'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['area'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <option value="<?php echo $vo['id']; ?>" <?php if($data['item']['area_id']==$vo['id']){echo 'selected';}?>><?php echo $vo['title']; ?></option>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
    </div>
    <label class="layui-form-label">&nbsp;&nbsp;&nbsp;&nbsp;</label>
    <div class="layui-input-inline">
    <button class="layui-btn layui-btn-sm" onclick="return false;" id="upload_img"><i class="layui-icon">&#xe67c;</i>上传图片</button>
    <img  id="pre_img" <?php if($data['item']['img']){echo 'src="'.$data['item']['img'].'"';}?> style="height:30px;" />
    <input type="hidden" name="img" value="<?php echo $data['item']['img']; ?>">
    </div>
  </div>


<div class="layui-form-item">
    <label class="layui-form-label">影片地址</label>
    <div class="layui-input-block">
        <input type="text"  class="layui-input" name="url" value="<?php echo $data['item']['url']; ?>" />
    </div>
</div>

<div class="layui-form-item">
    <label class="layui-form-label" >
        关键字
    </label>
    <div class="layui-input-inline">
        <input type="text" class="layui-input"  name="keywords" value="<?php echo $data['item']['keywords']; ?>" />
    </div>
</div>


    <div class="layui-form-item layui-form-text">
    <label class="layui-form-label">影片描述</label>
    <div class="layui-input-block">
      <textarea name="desc" placeholder="请输入内容" class="layui-textarea"><?php echo $data['item']['desc']; ?></textarea>
    </div>
  </div>





  <div class="layui-form-item">
    <label class="layui-form-label">状态</label>
    <div class="layui-input-inline">
      <input type="checkbox" name="status" title="发布" <?php if($data['item']['status']){echo 'checked';}?>  value="1" >
    </div>
  </div>




</form>


<div class="layui-form-item">
    <div class="layui-input-block">
        <button class="layui-btn" onclick="save()">保存</button>
    </div>
</div>


    <script type="text/javascript">
        layui.use(['layer','form','upload'],function(){

            form=layui.form;
            layer=layui.layer;
            $=layui.jquery;
           var upload = layui.upload;



          //执行实例 图片上传
          var uploadInst = upload.render({
            elem: '#upload_img' //绑定元素
            ,url: '/admins.php/admins/video/upload_img' //上传接口
            ,accept:'images'
            ,done: function(res){
              //上传完毕回调
              console.log(res);
              $("#pre_img").attr('src',res.msg);
              $('input[name="img"]').val(res.msg);
              // if(res.code>0){
              //   layer.alert(res.msg,{icon:2});
              // }else{
              //   layer.msg(res.msg);
              // }
            }
            ,error: function(){
              //请求异常回调
            }
          });

        });

        //保存
        function save(){

          var title=$.trim($('input[name="title"]').val());                //影片名称
          var url=$.trim($('input[name="url"]').val());                    //播放地址
             if(url=='')
            {
              layer.msg('请输入影片地址',{icon:2,'anim':6});
            }

            if(title==''){
              layer.msg('请输入影片名称',{icon:2,'anim':6});
            }


          $.post('/admins.php/admins/video/save',$('form').serialize(),function(res){
                    if(res.code>0){
                       layer.msg(res.msg,{icon:2,'anim':6});
                    }
                    else{
                      layer.msg(res.msg,{'icon':1});
                      setTimeout(function(){parent.window.location.reload()},1000);
                    }
          },'json');


        }
    </script>
</html>