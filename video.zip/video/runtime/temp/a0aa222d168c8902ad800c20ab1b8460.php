<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:68:"D:\web\www\video\public/../application/admins\view\home\welcome.html";i:1551264343;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <link rel="stylesheet" href="">
</head>
<body>
<div style="text-align:center;color:gray;font-size:20px;">欢迎来到后台管理系统</div>
</body>
</html>