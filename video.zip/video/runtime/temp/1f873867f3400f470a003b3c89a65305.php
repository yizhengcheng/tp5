<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"D:\web\www\video\public/../application/admins\view\slide\index.html";i:1551515863;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title></title>
    <link rel="stylesheet" href="/static/plusins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plusins/layui/layui.js"></script>
    <style type="text/css">
        .header span{background:#009688;margin-left: 30px;padding: 10px;color:#ffffff}
        .header div{border-bottom: solid 2px #009688;margin-top: 8px;}
        .header button{float:right;margin-top:-5px;}
    </style>
</head>
<body style="padding: 10px;">


    <div class="header">
        <span>幻灯片首页列表</span>
        <button class="layui-btn layui-btn-sm" onclick="add()">添加</button>
        <div></div>
    </div>

    <table class="layui-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>排序</th>
                <th>标题</th>
                <th>url</th>
                <th>图片</th>
                <th>操作</th>
            </tr>
        </thead>
        <tbody>
           <?php if(is_array($data['data']) || $data['data'] instanceof \think\Collection || $data['data'] instanceof \think\Paginator): $i = 0; $__LIST__ = $data['data'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <tr>
                <td><?php echo $vo['id']; ?></td>
                <td><?php echo $vo['ord']; ?></td>
                <td><?php echo $vo['title']; ?></td>
                <td><?php echo $vo['url']; ?></td>
               <td><img src="<?php echo $vo['img']; ?>" style="height: 30px;"></td>
                <td>
                    <button class="layui-btn layui-btn-xs" onclick="add(<?php echo $vo['id']; ?>)">编辑</button>
                    <button class="layui-btn layui-btn-danger layui-btn-xs" onclick="del(<?php echo $vo['id']; ?>)">删除</button>
                </td>
            </tr>
        </tbody>
        <?php endforeach; endif; else: echo "" ;endif; ?>


    </table>

    <script type="text/javascript">
        layui.use(['layer'],function(){

            layer=layui.layer;
            $=layui.jquery;
        });

        //添加幻灯片
        function add(id){
            layer.open({
            type: 2,
            title:id>0?'编辑幻灯片':'添加幻灯片',
            shade: 0.3,
            area: ['480px', '420px;'],
            content: '/admins.php/admins/Slide/add?id='+id //iframe的url
            });}


       // 删除
        function del(id){
            //
        layer.confirm('确认要删除？', {
            icon:3,//提示图标
          btn: ['确认','取消'] //按钮
        }, function(){
          $.post('/admins.php/admins/slide/delete', {'id':id}, function(res) {
              if(res.code>0){
                layer.alert(res.msg,{icno:2});
              }
              else{
                layer.msg(res.msg);
                setTimeout(function(){window.location.reload()},1000);
              }

          },'json');
        });

        }
    </script>

</body>
</html>