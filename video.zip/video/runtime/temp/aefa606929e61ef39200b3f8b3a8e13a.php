<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:66:"D:\web\www\video\public/../application/admins\view\site\index.html";i:1551430415;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>网站设置</title>
     <link rel="stylesheet" href="/static/plusins/layui/css/layui.css">
    <script type="text/javascript" src="/static/plusins/layui/layui.js"></script>
      <style type="text/css">
        .header span{background:#009688;margin-left: 30px;padding: 10px;color:#ffffff}
        .header div{border-bottom: solid 2px #009688;margin-top: 8px;}
        .header button{float:right;margin-top:-5px;}
    </style>
</head>
<body style="padding: 10px;">
 <div class="header">
        <span>网站设置</span>

        <div></div>
    </div>

    <form class="layui-form" style="margin-top: 10px;">
        <div class="layui-form-item">
            <label class="layui-form-lable">
                网站名称
            </label >
            <div class="layui-input-inline">
                <input type="text" class="layui-input"  name="title" value="<?php echo $site['values']; ?>" />
          </div>
        </div>
    </form>
    <div class="layui-form-item">
        <div class="layui-form-item">
        <button class="layui-btn" onclick="save()">提交</button>
    </div>
    </div>
</body>

 <script type="text/javascript">
        layui.use(['layer','form'],function(){

            form=layui.form;
            layer=layui.layer;
            $=layui.jquery;

        });

    function save(){
        var title = $.trim($('input[name="title"]').val());
        if(title==''){
            layer.msg('网站名称不能为空',{'icon':2});
            return;
        }
        $.post('/admins.php/admins/site/save',{'title':title},function(res){
            if(res.code>0){
                layer.msg(res.msg,{'icon':2});
            }else{
                layer.msg(res.msg,{'icon':1});
                setTimeout(function(){window.location.reload();},1000);
            }
        },'json');
    }


        </script>
</html>